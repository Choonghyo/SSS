import requests

# 서버의 IP 주소와 포트 번호 설정
server_ip = "223.130.143.92"
server_port = 8081 # 설정된 포트 번호

# 1. GET 요청: server_check.html 파일 확인
def check_server():
    url = f"http://{server_ip}:{server_port}/check"
    try:
        response = requests.get(url, timeout=10)  # 10초 타임아웃 설정
        print(f"Response Status Code: {response.status_code}")
        if response.status_code == 200:
            print("Server Response:")
            print(response.text)
        else:
            print(f"Error: Received status code {response.status_code} from server.")
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")

# 서버 확인 요청 보내기
check_server()
