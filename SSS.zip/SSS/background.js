// 백그라운드에서 실행될 코드
console.log('Background script is running');
